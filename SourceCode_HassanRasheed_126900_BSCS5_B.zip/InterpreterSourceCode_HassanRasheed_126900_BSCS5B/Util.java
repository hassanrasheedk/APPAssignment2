/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hassa
 */
import interpreter.Token;
import interpreter.TokenType;
import java.util.List;
public class Util
{
public static void Write(Object obj)
{
System.out.print(obj);
}
public static void Writeln(Object obj)
{
System.out.println(obj);
}
public static void Writeln()
{
System.out.println();
}
public static void PrettyPrint(List<Token> tokens)
{
int numberCount = 0;
int opCount = 0;
for (Token token: tokens)
{
if (token.type == TokenType.NUMBER)
{
Writeln("Number....: " + token.text);
numberCount++;
}
else
{
Writeln("Operator..: " + token.type);
opCount++;
}
}
Writeln("You have got "+
numberCount +
" different number and " +
opCount
+" operators.");
}
}