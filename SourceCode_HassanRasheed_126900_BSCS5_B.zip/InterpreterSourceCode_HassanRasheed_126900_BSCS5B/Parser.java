
import interpreter.TokenType;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hassa
 */
public class Parser {
    public boolean IsMulOp(TokenType type)
{
return type == TokenType.MULTIPLY || type == TokenType.DIVIDE;
}
public boolean IsAddOp(TokenType type)
{
return type == TokenType.ADD || type == TokenType.SUBTRACT;
}
public boolean IsMultiDigitOp(TokenType type)
{
return type == TokenType.LESSEQUAL || type == TokenType.GREATEREQUAL;
}
public boolean IsRelOp(TokenType type)
{
boolean lgOps = type == TokenType.LESS || type == TokenType.GREATER;
boolean eqOps = type == TokenType.EQUAL || type == TokenType.NOTEQUAL;
return eqOps || lgOps || IsMultiDigitOp(type);
}
public boolean IsLogicalOp(TokenType type)
{
return type == TokenType.OR || type == TokenType.AND;
}
public boolean IsNumber()
{
return CurrentToken().type == TokenType.NUMBER;
}
}
