/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpreter;

/**
 *
 * @author hassa
 */
public enum TokenType
{
NUMBER, NEWLINE, OPERATOR, EOF, UNKNOWN,
ADD, SUBTRACT, MULTIPLY, DIVIDE, LEFT_PAREN, RIGHT_PAREN, ASSIGNMENT,
LESS, GREATER, EQUAL, NOTEQUAL, LESSEQUAL, GREATEREQUAL, NOT, OR, AND
}
